/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1291
 *  net.minecraft.class_4081
 */
package net.romeosnowblitz.hmh2.effect;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

public class HealthShrikageEffect
extends class_1291 {
    public HealthShrikageEffect(class_4081 statusEffectCategory, int color) {
        super(statusEffectCategory, color);
    }

    public boolean method_5552(int pDuration, int pAmplifier) {
        return true;
    }
}

