/*
 * Decompiled with CFR 0.152.
 */
package net.romeosnowblitz.hmh2.entity;

public class ModSignTypes {
}

