/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2754
 */
package net.romeosnowblitz.hmh2.block.custom.piston;

import net.minecraft.class_2754;
import net.romeosnowblitz.hmh2.block.custom.piston.ModPistonType;

public class ModProperties {
    public static final class_2754<ModPistonType> PISTON_TYPE = class_2754.method_11850((String)"type", ModPistonType.class);
}

