/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_4970$class_2251
 *  net.minecraft.class_5778
 *  net.minecraft.class_7118
 */
package net.romeosnowblitz.hmh2.block.custom.test;

import net.minecraft.class_4970;
import net.minecraft.class_5778;
import net.minecraft.class_7118;

public class XRay
extends class_5778 {
    public XRay(class_4970.class_2251 settings) {
        super(settings);
    }

    public class_7118 method_41432() {
        return null;
    }
}

