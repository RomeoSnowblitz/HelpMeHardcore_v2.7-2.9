/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2404
 *  net.minecraft.class_3609
 *  net.minecraft.class_4970$class_2251
 */
package net.romeosnowblitz.hmh2.block.custom.block;

import net.minecraft.class_2404;
import net.minecraft.class_3609;
import net.minecraft.class_4970;

public class ModFluidBlock
extends class_2404 {
    public ModFluidBlock(class_3609 fluid, class_4970.class_2251 settings) {
        super(fluid, settings);
    }
}

