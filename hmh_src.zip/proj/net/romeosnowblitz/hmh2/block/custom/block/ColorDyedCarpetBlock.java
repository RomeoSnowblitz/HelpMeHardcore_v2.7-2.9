/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2577
 *  net.minecraft.class_4970$class_2251
 */
package net.romeosnowblitz.hmh2.block.custom.block;

import net.minecraft.class_2577;
import net.minecraft.class_4970;
import net.romeosnowblitz.hmh2.item.custom.dyes.ModDyeColor;

public class ColorDyedCarpetBlock
extends class_2577 {
    public ColorDyedCarpetBlock(ModDyeColor color, class_4970.class_2251 settings) {
        super(settings);
    }
}

