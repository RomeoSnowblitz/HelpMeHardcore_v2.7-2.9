/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2473
 *  net.minecraft.class_2647
 *  net.minecraft.class_4970$class_2251
 */
package net.romeosnowblitz.hmh2.block.custom.farm;

import net.minecraft.class_2473;
import net.minecraft.class_2647;
import net.minecraft.class_4970;

public class ModSaplingBlock
extends class_2473 {
    public ModSaplingBlock(class_2647 generator, class_4970.class_2251 settings) {
        super(generator, settings);
    }
}

