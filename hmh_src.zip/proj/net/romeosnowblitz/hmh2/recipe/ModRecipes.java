/*
 * Decompiled with CFR 0.152.
 */
package net.romeosnowblitz.hmh2.recipe;

public class ModRecipes {
    public static void registerRecipes() {
    }
}

