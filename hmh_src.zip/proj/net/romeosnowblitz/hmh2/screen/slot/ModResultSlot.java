/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1263
 *  net.minecraft.class_1735
 *  net.minecraft.class_1799
 */
package net.romeosnowblitz.hmh2.screen.slot;

import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class ModResultSlot
extends class_1735 {
    public ModResultSlot(class_1263 inventory, int index, int x, int y) {
        super(inventory, index, x, y);
    }

    public boolean method_7680(class_1799 stack) {
        return false;
    }
}

